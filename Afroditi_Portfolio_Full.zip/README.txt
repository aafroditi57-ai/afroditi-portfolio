AFRODITI GAVRIILIDOU — PORTFOLIO PACKAGE

FILES
- index.html: main portfolio
- digital-studio.html: standalone Digital Studio Landing concept
- Afroditi_Gavriilidou_CV_GR.pdf: CV PDF
- 404.html: friendly not-found page (supported by most static hosts)
- favicon.svg: browser tab icon
- robots.txt: basic crawl permission
- .nojekyll: GitHub Pages compatibility

PROJECT STATUS
Digital Studio Landing is an illustrative concept, not client work. InfoDaily is linked as a personal project. Other concepts are identified as such.

FUNCTIONALITY
- Main navigation scrolls to sections; mobile menu is interactive.
- Project cards open detail dialogs; external/project links open separately.
- Package buttons scroll to the contact form and preselect the chosen package.
- CV links open/download the local PDF. Keep the PDF in the same folder as index.html.
- Email, telephone and WhatsApp links use aafroditi57@gmail.com and +30 697 395 9126.
- The contact form uses mailto and opens the visitor's email app; it does not save submissions on a server.

FREE PUBLISHING (NOT YET DONE)
All files must be uploaded together to the same public site folder. No public URL has been created or verified yet.

GitHub Pages route:
1. Sign in to GitHub or create an account.
2. Create a public repository named exactly USERNAME.github.io (replace USERNAME with the GitHub username).
3. Upload all files from this folder, including the PDF, digital-studio.html, favicon.svg, 404.html, robots.txt and .nojekyll, to the repository root.
4. In Settings > Pages, select deployment from the main branch/root if it is not enabled automatically.
5. Wait for GitHub Pages to finish and open https://USERNAME.github.io.
6. Test the main page, Digital Studio project link, CV open/download, email, phone, WhatsApp, package buttons and mobile menu.

Before publication, replace USERNAME with the real GitHub username in the final URL. A custom domain is optional and is not included.
